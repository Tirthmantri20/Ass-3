package com.example.ass_3_3

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.chip.Chip
import java.net.URLEncoder
import java.util.Base64.Encoder

class MainActivity : AppCompatActivity() {
    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        val city: Chip = findViewById(R.id.chipCity)
        val state: Chip = findViewById(R.id.chipState)
        val Loc: Chip = findViewById(R.id.chipLoc)

        city.setOnClickListener {
            Loc.setText("Rajkot")
        }
        state.setOnClickListener {
            Loc.setText("Gujarat")
        }


        Loc.setOnClickListener {
            val uri = Uri.parse("geo:0,0?q="+ URLEncoder.encode(Loc.text.toString()))
            val intent = Intent(Intent.ACTION_VIEW, uri)
            intent.setPackage("com.google.android.apps.maps")
            startActivity(intent)
        }

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }
}