package com.example.ass_3_2

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.widget.ImageButton
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private var isFavorite = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val favoriteButton: ImageButton = findViewById(R.id.favoriteButton)
        val shareButton: ImageButton = findViewById(R.id.shareButton)

        // Favorite Button Click - Toggle Color & Show Toast
        favoriteButton.setOnClickListener {
            isFavorite = !isFavorite
            if (isFavorite) {
                favoriteButton.imageTintList = getColorStateList(R.color.red)
                Toast.makeText(this, "Added to Favorites", Toast.LENGTH_SHORT).show()
            } else {
                favoriteButton.clearColorFilter()
                Toast.makeText(this, "Removed from Favorites", Toast.LENGTH_SHORT).show()
            }
        }

        // Share Button Click - Share Painting Title
        shareButton.setOnClickListener {
            val shareIntent = Intent(Intent.ACTION_SEND)
            shareIntent.type = "text/plain"
            shareIntent.putExtra(Intent.EXTRA_TEXT, "Sky-line")
            startActivity(Intent.createChooser(shareIntent, "Share via"))
        }
    }
}
