package com.example.ass_3_4

import android.annotation.SuppressLint
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)


        loadData()
        val saveButton = findViewById<Button>(R.id.Save)
        val clearButton = findViewById<Button>(R.id.Clear)

        saveButton.setOnClickListener {
            saveData()
        }

        clearButton.setOnClickListener {
            clearData()
        }

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }

    private fun loadData() {
        val username = findViewById<EditText>(R.id.username)
        val password = findViewById<EditText>(R.id.password)
        var sharedPre = getSharedPreferences("login", MODE_PRIVATE)
        val nm1:String? = sharedPre.getString("username",null)
        val nm2:String? = sharedPre.getString("password",null)
        username.setText(nm1)
        password.setText(nm2)
    }

    @SuppressLint("ApplySharedPref")
    private fun clearData(){
        var sharedPre = getSharedPreferences("login", 0)
        val username = findViewById<EditText>(R.id.username)
        val password = findViewById<EditText>(R.id.password)
        sharedPre.edit().remove("username").apply()
        sharedPre.edit().remove("password").apply()
        username.text.clear()
        password.text.clear()

    }
    private fun saveData() {
        var sharedPre = getSharedPreferences("login", MODE_PRIVATE)
        val username = findViewById<EditText>(R.id.username)
        val password = findViewById<EditText>(R.id.password)
        val editor = sharedPre.edit()
        editor.apply(){
            putString("username",username.text.toString())
            putString("password",password.text.toString())
        }.apply()
        Toast.makeText(this, "Saved the Shared Preference", Toast.LENGTH_SHORT).show()

    }
}