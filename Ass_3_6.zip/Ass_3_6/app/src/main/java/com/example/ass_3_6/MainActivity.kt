package com.example.ass_3_6

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        val id: EditText = findViewById(R.id.id)
        val name: EditText = findViewById(R.id.name)
        val db = SQLHelper(this)

        val btnFirst: Button = findViewById(R.id.btnFirst)
        val btnLast: Button = findViewById(R.id.btnLast)
        val btnNext: Button = findViewById(R.id.btnNext)
        val btnPrevious: Button = findViewById(R.id.btnPrevious)
        val btnSave: Button = findViewById(R.id.btnSave)
        val btnUpdate: Button = findViewById(R.id.btnUpdate)
        val btnDelete: Button = findViewById(R.id.btnDelete)
        val btnshow: Button = findViewById(R.id.btnshow)
        val data : TextView = findViewById(R.id.data)
        var cursor = db.showData()

        btnSave.setOnClickListener {
            val a = db.insertData(id.text.toString().toInt(), name.text.toString())
            if (a > 0) {
                Toast.makeText(this, "Record Inserted", Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(this, "Failed!!!", Toast.LENGTH_LONG).show()
            }
            cursor.close()
            cursor = db.showData()
        }

        btnshow.setOnClickListener {

            if (cursor.count == 0) {
                Toast.makeText(this, "No Data Found", Toast.LENGTH_LONG).show()
            }
            data.text = buildString {
                cursor.moveToFirst()
                do {
                    append("ID: ${cursor.getInt(0)}, Name: ${cursor.getString(1)}\n")
                } while (cursor.moveToNext())
            }

        }
        btnFirst.setOnClickListener {
            cursor.moveToFirst()
            data.text = "ID:" + cursor.getInt(0) + " Name:" + cursor.getString(1)
            id.setText(cursor.getInt(0).toString())
            name.setText(cursor.getString(1))

        }
        btnLast.setOnClickListener {
            cursor.moveToLast()
            data.text = "ID:" + cursor.getInt(0) + " Name:" + cursor.getString(1)
            id.setText(cursor.getInt(0).toString())
            name.setText(cursor.getString(1))
        }
        btnNext.setOnClickListener {
            try{
                cursor.moveToNext()
                data.text = "ID:" + cursor.getInt(0) + " Name:" + cursor.getString(1)
                id.setText(cursor.getInt(0).toString())
                name.setText(cursor.getString(1))
            }catch (e:Exception){
                Toast.makeText(this, "No More Data", Toast.LENGTH_LONG).show()
            }

        }
        btnPrevious.setOnClickListener {
            try {
                cursor.moveToPrevious()
                data.text = "ID:" + cursor.getInt(0) + " Name:" + cursor.getString(1)
                id.setText(cursor.getInt(0).toString())
                name.setText(cursor.getString(1))
            }catch (e:Exception){
                Toast.makeText(this, "No Previous Data", Toast.LENGTH_LONG).show()
            }

        }
        btnUpdate.setOnClickListener {
            val a = db.updateData(id.text.toString().toInt(), name.text.toString())
            if (a > 0) {
                Toast.makeText(this, "Record Updated", Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(this, "Failed!!!", Toast.LENGTH_LONG).show()
            }
            cursor.close()
            cursor = db.showData()
        }
        btnDelete.setOnClickListener {
            val a = db.deleteData(id.text.toString().toInt())
            if (a > 0) {
                Toast.makeText(this, "Record Deleted", Toast.LENGTH_LONG).show()
            }else{
                Toast.makeText(this, "Failed!!!", Toast.LENGTH_LONG).show()
            }
            cursor.close()
            cursor = db.showData()
        }


        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }
}