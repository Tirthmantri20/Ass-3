package com.example.ass_3_6

import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class SQLHelper(context: Context) : SQLiteOpenHelper(context, "EmpDB", null, 1){


    override fun onCreate(db: SQLiteDatabase?) {
        if (db != null) {
            db.execSQL("create table Employee(id integer primary key, name text)")
        }

    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        TODO("Not yet implemented")
    }

    fun insertData(id: Int, name: String): Long {
        val db = this.writableDatabase
        val values = ContentValues().apply {
            put("id", id)
            put("name", name)
        }

        return try {
            db.insertOrThrow("Employee", null, values)
        } catch (e: Exception) {
            e.printStackTrace()
            -1
        } finally {
            db.close()
        }
    }


    fun updateData(id: Int, name: String): Int {
        val db = this.writableDatabase
        val values = ContentValues()
        values.put("name", name)
        val l = db.update("Employee", values, "id=$id", null)
        return l
    }

    fun deleteData(id: Int): Int {
        val db = this.writableDatabase
        val l = db.delete("Employee", "id=$id", null)
        return l
    }

    fun showData(): Cursor {
        val db = this.readableDatabase
        val l = db.rawQuery("select * from Employee", null)
        return l
    }

}