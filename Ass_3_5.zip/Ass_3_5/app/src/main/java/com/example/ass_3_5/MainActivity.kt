package com.example.ass_3_5

import android.os.Bundle
import android.text.TextUtils
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.*

class MainActivity : AppCompatActivity() {

    private lateinit var edtID: EditText
    private lateinit var edtName: EditText
    private lateinit var edtSalary: EditText
    private lateinit var btnSave: Button
    private lateinit var btnDelete: Button
    private lateinit var btnUpdate: Button
    private lateinit var btnShow: Button
    private lateinit var txtData: TextView

    private lateinit var databaseReference: DatabaseReference

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        edtID = findViewById(R.id.id)
        edtName = findViewById(R.id.name)
        edtSalary = findViewById(R.id.salary)
        btnSave = findViewById(R.id.save)
        btnDelete = findViewById(R.id.delete)
        btnUpdate = findViewById(R.id.update)
        btnShow = findViewById(R.id.show)
        txtData = findViewById(R.id.txtData)

        databaseReference = FirebaseDatabase.getInstance().reference.child("Employees")

        // Button Click Listeners
        btnSave.setOnClickListener { saveData() }
        btnUpdate.setOnClickListener { updateData() }
        btnDelete.setOnClickListener { deleteData() }
        btnShow.setOnClickListener { fetchData() }
    }

    private fun saveData() {
        val id = edtID.text.toString().trim()
        val name = edtName.text.toString().trim()
        val salary = edtSalary.text.toString().trim()

        if (TextUtils.isEmpty(id) || TextUtils.isEmpty(name) || TextUtils.isEmpty(salary)) {
            Toast.makeText(this, "All fields are required", Toast.LENGTH_SHORT).show()
            return
        }

        val employee = Employee(id, name, salary)
        databaseReference.child(id).setValue(employee)
            .addOnSuccessListener {
                Toast.makeText(this, "Data Saved", Toast.LENGTH_SHORT).show()
                clearFields()
            }
            .addOnFailureListener {
                Toast.makeText(this, "Failed to save", Toast.LENGTH_SHORT).show()
            }
    }

    private fun updateData() {
        val id = edtID.text.toString().trim()
        val name = edtName.text.toString().trim()
        val salary = edtSalary.text.toString().trim()

        if (TextUtils.isEmpty(id)) {
            Toast.makeText(this, "Enter ID to update", Toast.LENGTH_SHORT).show()
            return
        }

        val updates = mapOf("name" to name, "salary" to salary)
        databaseReference.child(id).updateChildren(updates)
            .addOnSuccessListener {
                Toast.makeText(this, "Data Updated", Toast.LENGTH_SHORT).show()
                clearFields()
            }
            .addOnFailureListener {
                Toast.makeText(this, "Failed to update", Toast.LENGTH_SHORT).show()
            }
    }

    private fun deleteData() {
        val id = edtID.text.toString().trim()

        if (TextUtils.isEmpty(id)) {
            Toast.makeText(this, "Enter ID to delete", Toast.LENGTH_SHORT).show()
            return
        }

        databaseReference.child(id).removeValue()
            .addOnSuccessListener {
                Toast.makeText(this, "Data Deleted", Toast.LENGTH_SHORT).show()
                clearFields()
            }
            .addOnFailureListener {
                Toast.makeText(this, "Failed to delete", Toast.LENGTH_SHORT).show()
            }
    }

    private fun fetchData() {
        databaseReference.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val data = StringBuilder()
                for (dataSnapshot in snapshot.children) {
                    val employee = dataSnapshot.getValue(Employee::class.java)
                    if (employee != null) {
                        data.append("ID: ${employee.id}\n")
                            .append("Name: ${employee.name}\n")
                            .append("Salary: ${employee.salary}\n\n")
                    }
                }
                txtData.text = data.toString()
            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(this@MainActivity, "Failed to load data", Toast.LENGTH_SHORT).show()
            }
        })
    }

    private fun clearFields() {
        edtID.text.clear()
        edtName.text.clear()
        edtSalary.text.clear()
    }
}
