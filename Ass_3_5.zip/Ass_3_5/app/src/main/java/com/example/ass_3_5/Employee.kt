package com.example.ass_3_5

data class Employee(
    var id: String? = null,
    var name: String? = null,
    var salary: String? = null
)